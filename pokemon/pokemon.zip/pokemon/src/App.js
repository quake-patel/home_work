import './App.css';
import View from './View';

function App() {
  return (
    <div className="App">
      <View />
    </div>
  );
}

export default App;
